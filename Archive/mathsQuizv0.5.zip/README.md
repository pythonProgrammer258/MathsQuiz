# MathsQuiz

<img src="logo.png" /><br>

To play this quiz game, you have to install python. Then you can run run-windows.py (on Windows) or run-linux.py (on linux)<br><br>

Rules<br>
<ol>
<li>To win you have to collect 1000 points (normal mode), 2000 points (extreme mode) or 500 points (easy mode)</li>
<li>There are 5 difficulty levels: very easy, easy, medium,  hard and extreme (normal mode)</li>
<li>You can get help: give up without losing points (type qw) (only one) and get new questions (type ty) (only one) (normal and easy mode)</li>
<li>Helps are active after first question</li>
<li>If the answer to the first question is wrong, you will fail</li>
<li>The helps arent available in extreme difficulty and extreme mode</li>
</ol>
