import data
import random
s = 1
d = 50

print('0.4 test5')
print('Rules:')
print('1) To win you have to collect 1000 points')
print('2) There are 4 difficulty levels: very easy, easy, medium,  hard')
print('3) You can choose hard difficulty only five per game')
print('4) You can get help: give up without losing points (type qw) (only one) and get new questions (type ty) (only one)')
print('5) Helps are active after second question')
print('6) If your answer answer to the first question will be bad, you lose')

score = 0

qw = 0
er = 0
ty = 0

easy = 0
hard = 0
real_hard = 0
extreme = 0
sl = random.choice(data.secret_level)
print('Select difficulty:')
print('1. Very easy - 1/0 points (unlimited)')
print('2. Easy - 5/10 points (50)')
print('3. Medium - 10/20 points (20)')
print('4. Hard - 50/100 points (10) - after first round')
print('5. Extreme - win/lose (1) - testing')
print('Ultra rare secret level (<0.5% per game) - 200/lose')
print('Rare level (2% per round) - 900/0')
difficulty = input('')
rn = random.choice(data.random)
if (difficulty == '1') and (rn != 25) and (sl != 1):
    e = random.choice(data.easy)
    print(e)
    ans = input('')
    if e == data.e1:
        if ans == '4':
            score = score + 1
        else:
            score = -200
    if e == data.e2:
        if ans == '5':
            score = score + 1
        else:
            score = -200
    if e == data.e3:
        if ans == '10':
            score = score + 1
        else:
            score = -200
    if e == data.e4:
        if ans == '12':
            score = score + 1
        else:
            score = -200
    if e == data.e5:
        if ans == '10':
            score = score + 1
        else:
            score = -200
    if e == data.e6:
        if ans == '12':
            score = score + 1
        else:
            score = -200
    if e == data.e7:
        if ans == '0':
            score = score + 1
        else:
            score = -200
    if e == data.e8:
        if ans == '1':
            score = score + 1
        else:
            score = -200
    if e == data.e9:
        if ans == '0':
            score = score + 1
        else:
            score = -200
    if e == data.e10:
        if ans == '5':
            score = score + 1
        else:
            score = -200
    if e == data.e11:
        if ans == '4':
            score = score + 1
        else:
            score = -200
    if e == data.e12:
        if ans == '4':
            score = score + 1
        else:
            score = -200

if (difficulty == '2') and (rn != 25) and (sl != 1):
    easy = easy + 1
    m = random.choice(data.medium)
    print(m)
    ans = input('')
    if m == data.m1:
        if ans == '45':
            score = score + 5
        else:
            score = -200
    if m == data.m2:
        if ans == '40':
            score = score + 5
        else:
            score = -200
    if m == data.m3:
        if ans == '24':
            score = score + 5
        else:
            score = -200
    if m == data.m4:
        if ans == '10':
            score = score + 5
        else:
            score = -200
    if m == data.m5:
        if ans == '24':
            score = score + 5
        else:
            score = -200
    if m == data.m6:
        if ans == '36':
            score = score + 5
        else:
            score = -200
    if m == data.m7:
        if ans == '1':
            score = score + 5
        else:
            score = -200
    if m == data.m8:
        if ans == '4':
            score = score + 5
        else:
            score = -200
    if m == data.m9:
        if ans == '6':
            score = score + 5
        else:
            score = -200
    if m == data.m10:
        if ans == '15':
            score = score + 5
        else:
            score = -200
    if m == data.m11:
        if ans == '8':
            score = score + 5
        else:
            score = -200
    if m == data.m12:
        if ans == '338.9':
            score = score + 5
        else:
            score = -200

if (difficulty == '3') and (hard != 20) and (rn != 25) and (sl != 1):
    hard = hard + 1
    h = random.choice(data.hard)
    print(h)
    ans = input('')
    if h == data.h1:
        if ans == '9':
            score = score + 10
        else:
            score = -200
    if h == data.h4:
        if ans == '27':
            score = score + 10
        else:
            score = -200
    if h == data.h5:
        if ans == '16':
            score = score + 10
        else:
            score = -200
    if h == data.h6:
        if ans == '32':
            score = score + 10
        else:
            score = -200
    if h == data.h7:
        if ans == '1024':
            score = score + 10
        else:
            score = -200
    if h == data.h8:
        if ans == '2048':
            score = score + 10
        else:
            score = -2000
if rn == 25 and sl != 1:
    print('Congratulations, you unlocked rare level. You can collect 900 points!')
    print('50+49')
    ans = input('')
    if ans == '99':
        score = score + 900
    else:
        score = score
if sl == 1:
    print('=====================ULTRA SECRET LEVEL UNLOCKED=====================')
    print('Congratulations, you unlocked ultra rare and secret level.')
    print('To choice this level, enter 205048@5.wmP')
    print('Password 1: 2048')
    print('Password 2: 4986')
    print('Password 3: 9521')
    print('Password 4: 2589')
print('Score: ', score)
op = True
if score < -199:
    print('You lose')
    op = False
while op:

    rn = random.choice(data.random)
    difficulty = input('Select difficulty: ')
    if (difficulty == '1') and (rn != 25):
        e = random.choice(data.easy)
        print(e)
        ans = input('')
        if e == data.e1:
            if ans == '4':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e2:
            if ans == '5':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e3:
            if ans == '10':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e4:
            if ans == '12':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e5:
            if ans == '10':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e6:
            if ans == '12':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e7:
            if ans == '0':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e8:
            if ans == '1':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e9:
            if ans == '0':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e10:
            if ans == '5':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e11:
            if ans == '4':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score
        if e == data.e12:
            if ans == '4':
                score = score + 1
            elif (ans == 'qw') and (qw == 0):
                score = score + 1
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score

    if (difficulty == '2') and (rn != 25) and (easy < 49.9):
        easy = easy + 1
        m = random.choice(data.medium)
        print(m)
        ans = input('')
        if m == data.m1:
            if ans == '45':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m2:
            if ans == '40':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m3:
            if ans == '24':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m4:
            if ans == '10':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m5:
            if ans == '24':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m6:
            if ans == '36':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m7:
            if ans == '1':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m8:
            if ans == '4':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m9:
            if ans == '6':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m10:
            if ans == '15':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m11:
            if ans == '8':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10
        if m == data.m12:
            if ans == '338.9':
                score = score + 5
            elif (ans == 'qw') and (qw == 0):
                score = score + 5
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 10

    if (difficulty == '3') and (hard < 19.9) and (rn != 25):
        hard = hard + 1
        h = random.choice(data.hard)
        print(h)
        ans = input('')
        if h == data.h1:
            if ans == '9':
                score = score + 10
            elif (ans == 'qw') and (qw == 0):
                score = score + 10
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 20
        if h == data.h4:
            if ans == '27':
                score = score + 10
            elif (ans == 'qw') and (qw == 0):
                score = score + 10
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 20
        if h == data.h5:
            if ans == '16':
                score = score + 10
            elif (ans == 'qw') and (qw == 0):
                score = score + 10
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 20
        if h == data.h6:
            if ans == '32':
                score = score + 10
            elif (ans == 'qw') and (qw == 0):
                score = score + 10
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 20
        if h == data.h7:
            if ans == '1024':
                score = score + 10
            elif (ans == 'qw') and (qw == 0):
                score = score + 10
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 20
        if h == data.h8:
            if ans == '2048':
                score = score + 10
            elif (ans == 'qw') and (qw == 0):
                score = score + 10
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 20
    if difficulty == 'game.addScore(50)':
        score = score + 50
    if difficulty == 'SuperSecretLevel':
        ss=random.choice(data.super_secret)
        add = random.choice(data.points)
    if difficulty == 'game.superSecretCommands':
        print('SuperSecretLevel - new level')
        print('game.addScore(50) - add 50 to score')
        print(ss)
        ans = input('')
        if ss == data.ss1:
            if ans == '120':
                score = score + add
            else:
                score = score - add
        if ss == data.ss2:
            if ans == '2':
                score = score + add
            else:
                score = score - add
        if ss == data.ss3:
            if ans == '24':
                score = score + add
            else:
                score = score - add
        if ss == data.ss4:
            if ans == '8':
                score = score + add
            else:
                score = score - add
        if ss == data.ss3:
            if ans == '4':
                score = score + add
            else:
                score = score - add
    if (difficulty == '4') and (real_hard < 9.9) and (rn != 25):
        real_hard = real_hard + 1
        rh = random.choice(data.real_hard)
        print(rh)
        ans = input('')
        if rh == data.rh1:
            if ans == '40320':
                score = score + 50
            elif (ans == 'qw') and (qw == 0):
                score = score + 50
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 100
        if rh == data.rh2:
            if ans == '24':
                score = score + 50
            elif (ans == 'qw') and (qw == 0):
                score = score + 50
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 100
        if rh == data.rh3:
            if ans == '120':
                score = score + 50
            elif (ans == 'qw') and (qw == 0):
                score = score + 50
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 100
        if rh == data.rh4:
            if ans == '3628800':
                score = score + 500
            elif (ans == 'qw') and (qw == 0):
                score = score + 50
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 100
        if rh == data.rh5:
            if ans == '720':
                score = score + 50
            elif (ans == 'qw') and (qw == 0):
                score = score + 50
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 100
        if rh == data.rh6:
            if ans == '362880':
                score = score + 50
            elif (ans == 'qw') and (qw == 0):
                score = score + 50
                qw = qw + 1
            elif (ans == 'ty') and (ty == 0):
                ty = ty + 1
            else:
                score = score - 100
    if (difficulty == '5') and (extreme == 0):
        print('Testing...')
    if (difficulty == '2') and (easy > 49.9):
        print('No more easy questions')
    if (difficulty == '3') and (hard > 19.9):
        print('Normal difficulty is out')
    if (difficulty == '5') and (extreme > 0.9):
        print('Extreme difficulty is only one time per game')

    if rn == 25:
        print('Congratulations, you unlocked rare level. You can collect 900 points, but you cant use help')
        print('50+49')
        ans = input('')
        if ans == '99':
            score = score + 900
        else:
            score = score
    if difficulty == '205048@5.wmP':
        p = random.choice(data.passes)
        if p == data.pass1:
            print('Enter password 1')
        if p == data.pass2:
            print('Enter password 2')
        if p == data.pass3:
            print('Entar password 3')
        else:
            print('Enter password 4')
        password = input('')
        if p == data.pass1 and password == data.pass1:
            q = random.choice(data.ulta_rare)
            print(q)
            ans = input('')
            if q == data.ur1:
                if ans == '12':
                    score = score + 200
                else:
                    score = -200

            if q == data.ur2:
                if ans == '36':
                    score = score + 200
                else:
                    score = -200
            if q == data.ur3:
                if ans == '3':
                    score = score + 200
                else:
                    score = -200
        if p == data.pass2 and password == data.pass2:
            q = random.choice(data.ulta_rare)
            print(q)
            ans = input('')
            if q == data.ur1:
                if ans == '12':
                    score = score + 200
                else:
                    score = -200

            if q == data.ur2:
                if ans == '36':
                    score = score + 200
                else:
                    score = -200
            if q == data.ur3:
                if ans == '3':
                    score = score + 200
                else:
                    score = -200
        if p == data.pass3 and password == data.pass3:
            q = random.choice(data.ulta_rare)
            print(q)
            ans = input('')
            if q == data.ur1:
                if ans == '12':
                    score = score + 200
                else:
                    score = -200

            if q == data.ur2:
                if ans == '36':
                    score = score + 200
                else:
                    score = -200
            if q == data.ur3:
                if ans == '3':
                    score = score + 200
                else:
                    score = -200
        if p == data.pass4 and password == data.pass4:
            q = random.choice(data.ulta_rare)
            print(q)
            ans = input('')
            if q == data.ur1:
                if ans == '12':
                    score = score + 200
                else:
                    score = -200

            if q == data.ur2:
                if ans == '36':
                    score = score + 200
                else:
                    score = -200
            if q == data.ur3:
                if ans == '3':
                    score = score + 200
                else:
                    score = -200
        else:
            print('Incorrect password')
    print('Score: ', score)
    if score > 999:
        print('You win!')
        op = False
    if score < -199:
        print('You lose')
        op = False
pass
