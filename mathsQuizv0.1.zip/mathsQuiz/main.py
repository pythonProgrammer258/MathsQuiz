import data
import random

s = 1
d = 50
print('Maths quiz v0.1')
print('Rules:')
print('1) To win you have to collect 1000 points')
print('2) There are 3 difficulty levels: easy, medium and hard, which you can choose, and one, ultra rare (and easy) '
      '(2%) where you can collect 900 points or 0 lose (actually dont work)')
print('3) You can choose hard difficulty only one per game')
print('Have fun!')
print('Press enter to start')
input('')
score = 0

easy = 0
medium = 0
hard = 0
print('Select difficulty:')
print('1. Easy - 10/50 points (unlimited)')
print('2. Normal - 20/va banque points (unlimited)')
print('3. Hard - 50/game over points (only one)')

difficulty = input('')

if difficulty == '1':
    easy = score + 1
    e = random.choice(data.easy)
    print(e)
    ans = input('')
    if e == data.e1:
        if ans == '4':
            score = score + 10
        else:
            score =- 50
    if e == data.e2:
        if ans == '5':
            score = score + 10
        else:
            score =- 50
    if e == data.e3:
        if ans == '10':
            score = score + 10
        else:
            score =- 50
    if e == data.e4:
        if ans == '12':
            score = score + 10
        else:
            score =- 50
    if e == data.e5:
        if ans == '10':
            score = score + 10
        else:
            score =- 50
    if e == data.e6:
        if ans == '12':
            score = score + 10
        else:
            score =- 50
    if e == data.e7:
        if ans == '0':
            score = score + 10
        else:
            score =- 50
    if e == data.e8:
        if ans == '1':
            score = score + 10
        else:
            score =- 50
    if e == data.e9:
        if ans == '0':
            score = score + 10
        else:
            score =- 50
    if e == data.e10:
        if ans == '5':
            score = score + 10
        else:
            score =- 50
    if e == data.e11:
        if ans == '4':
            score = score + 10
        else:
            score = - 50
    if e == data.e12:
        if ans == '4':
            score = score + 10
        else:
            score =- 50

if difficulty == '2':
    medium = score + 1
    m = random.choice(data.medium)
    print(m)
    ans = input('')
    if m == data.m1:
        if ans == '45':
            score = score + 20
        else:
            score = 0
    if m == data.m2:
        if ans == '40':
            score = score + 20
        else:
            score = 0
    if m == data.m3:
        if ans == '24':
            score = score + 20
        else:
            score = 0
    if m == data.m4:
        if ans == '10':
            score = score + 20
        else:
            score = 0
    if m == data.m5:
        if ans == '24':
            score = score + 20
        else:
            score = 0
    if m == data.m6:
        if ans == '36':
            score = score + 20
        else:
            score = 0
    if m == data.m7:
        if ans == '1':
            score = score + 20
        else:
            score = 0
    if m == data.m8:
        if ans == '4':
            score = score + 20
        else:
            score = 0
    if m == data.m9:
        if ans == '6':
            score = score + 20
        else:
            score = 0
    if m == data.m10:
        if ans == '15':
            score = score + 20
        else:
            score = 0
    if m == data.m11:
        if ans == '8':
            score = score + 20
        else:
            score = 0
    if m == data.m12:
        if ans == '338.9':
            score = score + 20
        else:
            score = 0

if (difficulty == '3') and (hard == 0):
    hard = score + 1
    h = random.choice(data.hard)
    print(h)
    ans = input('')
    if h == data.h1:
        if ans == '9':
            score = score + 50
        else:
            score = -200
    if h == data.h2:
        if ans == '40320':
            score = score + 500
        else:
            score = 0
    if h == data.h3:
        if ans == '24':
            score = score + 50
        else:
            score = -200
    if h == data.h4:
        if ans == '27':
            score = score + 50
        else:
            score = -200
    if h == data.h5:
        if ans == '16':
            score = score + 50
        else:
            score = -200
    if h == data.h6:
        if ans == '32':
            score = score + 50
        else:
            score = -200
    if h == data.h7:
        if ans == '1024':
            score = score + 50
        else:
            score = -200
    if h == data.h8:
        if ans == '2048':
            score = score + 50
        else:
            score = -200
if (difficulty == '3') and (hard != 0):
    print('Hard difficulty is only one per game')
print('Score: ', score)
op = True

while op:
    difficulty = input('Select difficulty: ')
    if (difficulty == '3') and (hard != 0):
        print('Hard difficulty is only one per game')
    else:
        pass
    if difficulty == '1':
        easy = score + 1
        e = random.choice(data.easy)
        print(e)
        ans = input('')
        if e == data.e1:
            if ans == '4':
                score = score + 10
            else:
                score = - 50
        if e == data.e2:
            if ans == '5':
                score = score + 10
            else:
                score = - 50
        if e == data.e3:
            if ans == '10':
                score = score + 10
            else:
                score = - 50
        if e == data.e4:
            if ans == '12':
                score = score + 10
            else:
                score = - 50
        if e == data.e5:
            if ans == '10':
                score = score + 10
            else:
                score = - 50
        if e == data.e6:
            if ans == '12':
                score = score + 10
            else:
                score = - 50
        if e == data.e7:
            if ans == '0':
                score = score + 10
            else:
                score = - 50
        if e == data.e8:
            if ans == '1':
                score = score + 10
            else:
                score = - 50
        if e == data.e9:
            if ans == '0':
                score = score + 10
            else:
                score = - 50
        if e == data.e10:
            if ans == '5':
                score = score + 10
            else:
                score = - 50
        if e == data.e11:
            if ans == '4':
                score = score + 10
            else:
                score = - 50
        if e == data.e12:
            if ans == '4':
                score = score + 10
            else:
                score = - 50

    elif difficulty == '2':
        medium = score + 1
        m = random.choice(data.medium)
        print(m)
        ans = input('')
        if m == data.m1:
            if ans == '45':
                score = score + 20
            else:
                score = 0
        if m == data.m2:
            if ans == '40':
                score = score + 20
            else:
                score = 0
        if m == data.m3:
            if ans == '24':
                score = score + 20
            else:
                score = 0
        if m == data.m4:
            if ans == '10':
                score = score + 20
            else:
                score = 0
        if m == data.m5:
            if ans == '24':
                score = score + 20
            else:
                score = 0
        if m == data.m6:
            if ans == '36':
                score = score + 20
            else:
                score = 0
        if m == data.m7:
            if ans == '1':
                score = score + 20
            else:
                score = 0
        if m == data.m8:
            if ans == '4':
                score = score + 20
            else:
                score = 0
        if m == data.m9:
            if ans == '6':
                score = score + 20
            else:
                score = 0
        if m == data.m10:
            if ans == '15':
                score = score + 20
            else:
                score = 0
        if m == data.m11:
            if ans == '8':
                score = score + 20
            else:
                score = 0
        if m == data.m12:
            if ans == '338.9':
                score = score + 20
            else:
                score = 0

    if (difficulty == '3') and (hard == 0):
        hard = score + 1
        h = random.choice(data.hard)
        print(h)
        ans = input('')
        if h == data.h1:
            if ans == '9':
                score = score + 50
            else:
                score = -200
        if h == data.h2:
            if ans == '40320':
                score = score + 500
            else:
                score = 0
        if h == data.h3:
            if ans == '24':
                score = score + 50
            else:
                score = -200
        if h == data.h4:
            if ans == '27':
                score = score + 50
            else:
                score = -200
        if h == data.h5:
            if ans == '16':
                score = score + 50
            else:
                score = -200
        if h == data.h6:
            if ans == '32':
                score = score + 50
            else:
                score = -200
        if h == data.h7:
            if ans == '1024':
                score = score + 50
            else:
                score = -200
        if h == data.h8:
            if ans == '2048':
                score = score + 50
            else:
                score = -200

    print('Score: ', score)
    if score > 999:
        print('You win!')
        op = False
    if score < -199:
        print('You lose')
        op = False
